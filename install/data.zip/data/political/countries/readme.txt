Dataset: Kaartlagen van de Wereld
Datum: Augustus 2006
Van: Geodan IT
Site: http://www.geodan.nl
Email: Info@geodan.nl
Tel: 020-5711311
-------------------------------

Demodata
~~~~~~~~

De demodata bestaat uit de kaartlagen:
- WorldCountries : Wereld, landsgrenzen met aantal inwoners en meerdere demografische parameters.

Gebruiksbeperkingen
~~~~~~~~~~~~~~~~~~~
Deze bestanden mogen alleen gebruikt worden voor 
test en demonstratie doeleinden.

+++